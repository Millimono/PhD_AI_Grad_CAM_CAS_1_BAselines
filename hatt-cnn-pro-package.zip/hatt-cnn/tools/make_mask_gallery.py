"""
Render a gallery of the heuristic mask families defined in MaskGenerator.

Usage:
    python tools/make_mask_gallery.py
Output:
    docs/figures/mask_gallery.png
"""
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import torch

# Allow importing MaskGenerator from the repo root
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from MaskGenerator import MaskGenerator  # noqa: E402

SHAPE = (1, 1, 96, 96)  # (B, C, H, W) — purely for visualization

# (mask_type, kwargs, pretty title)
MASKS = [
    ("center", {}, "M_Center"),
    ("circle", {}, "M_Circle"),
    ("border", {}, "M_Border"),
    ("ellipse", {}, "M_Ellipse"),
    ("gaussian_anisotropic", {}, "M_GaussAniso"),
    ("gaussian_mixture", {}, "M_GaussMix"),
    ("radial", {}, "M_Radial"),
    ("directional", {}, "M_Directional"),
    ("sigmoid", {}, "M_Sigmoid"),
    ("ring", {}, "M_Ring"),
]


def main():
    gen = MaskGenerator(device="cpu")
    out_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "docs", "figures"
    )
    os.makedirs(out_dir, exist_ok=True)

    cols = 5
    rows = (len(MASKS) + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(2.2 * cols, 2.4 * rows))
    axes = axes.ravel()

    for ax, (mtype, kwargs, title) in zip(axes, MASKS):
        with torch.no_grad():
            mask = gen.generate(SHAPE, mtype, **kwargs)[0, 0].cpu().numpy()
        ax.imshow(mask, cmap="magma")
        ax.set_title(title, fontsize=11)
        ax.axis("off")

    for ax in axes[len(MASKS):]:
        ax.axis("off")

    fig.suptitle("HAtt-CNN — Heuristic attention-mask families", fontsize=14, y=1.0)
    fig.tight_layout(rect=[0, 0, 1, 0.97])
    fig.subplots_adjust(hspace=0.35)
    out_path = os.path.join(out_dir, "mask_gallery.png")
    fig.savefig(out_path, dpi=130, bbox_inches="tight")
    print(f"✅ Saved {out_path}")


if __name__ == "__main__":
    main()
